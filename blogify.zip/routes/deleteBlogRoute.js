// deleteBlogRoute.js

const express = require('express');
const router = express.Router();
const Blog = require('../models/blog');

router.post('/:id/delete', async (req, res) => {
  try {
    // Find the blog post by ID and check if the current user is the creator
    const blog = await Blog.findOne({ _id: req.params.id, createdBy: req.user._id });
    if (!blog) {
      // If the blog post doesn't exist or the current user is not the creator, return 404
      return res.status(404).send('Blog not found');
    }
    // If the current user is the creator, delete the blog post
    await blog.remove();
    res.redirect('/');
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

module.exports = router;
